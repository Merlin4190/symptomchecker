﻿<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="https://gmpg.org/xfn/11">

<title>Check Your Medical Symptoms &#8211; TheDoctorsOnline</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="TheDoctorsOnline &raquo; Feed" href="http://thedoctorsonline.org/feed/" />
<link rel="alternate" type="application/rss+xml" title="TheDoctorsOnline &raquo; Comments Feed" href="http://thedoctorsonline.org/comments/feed/" />
        <script type="text/javascript">
            window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/thedoctorsonline.org\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.0.3"}};
            !function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
        </script>
        <style type="text/css">
img.wp-smiley,
img.emoji {
    display: inline !important;
    border: none !important;
    box-shadow: none !important;
    height: 1em !important;
    width: 1em !important;
    margin: 0 .07em !important;
    vertical-align: -0.1em !important;
    background: none !important;
    padding: 0 !important;
}
</style>
<link rel='stylesheet' id='gtranslate-style-css'  href='http://thedoctorsonline.org/wp-content/plugins/gtranslate/gtranslate-style24.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='http://thedoctorsonline.org/wp-includes/css/dashicons.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='admin-bar-css'  href='http://thedoctorsonline.org/wp-includes/css/admin-bar.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='astra-theme-css-css'  href='http://thedoctorsonline.org/wp-content/themes/astra/assets/css/minified/style.min.css?ver=1.6.3' type='text/css' media='all' />
<style id='astra-theme-css-inline-css' type='text/css'>
html{font-size:81.25%;}a,.page-title{color:#075aae;}a:hover,a:focus{color:#000000;}body,button,input,select,textarea{font-family:'Montserrat',sans-serif;font-weight:400;font-size:13px;font-size:1rem;}blockquote{border-color:rgba(7,90,174,0.05);}h1,.entry-content h1,.entry-content h1 a,h2,.entry-content h2,.entry-content h2 a,h3,.entry-content h3,.entry-content h3 a,h4,.entry-content h4,.entry-content h4 a,h5,.entry-content h5,.entry-content h5 a,h6,.entry-content h6,.entry-content h6 a,.site-title,.site-title a{font-family:'Montserrat',sans-serif;font-weight:300;}.site-title{font-size:35px;font-size:2.6923076923077rem;}.ast-archive-description .ast-archive-title{font-size:40px;font-size:3.0769230769231rem;}.site-header .site-description{font-size:15px;font-size:1.1538461538462rem;}.entry-title{font-size:30px;font-size:2.3076923076923rem;}.comment-reply-title{font-size:21px;font-size:1.6153846153846rem;}.ast-comment-list #cancel-comment-reply-link{font-size:13px;font-size:1rem;}h1,.entry-content h1,.entry-content h1 a{font-size:60px;font-size:4.6153846153846rem;}h2,.entry-content h2,.entry-content h2 a{font-size:40px;font-size:3.0769230769231rem;}h3,.entry-content h3,.entry-content h3 a{font-size:21px;font-size:1.6153846153846rem;}h4,.entry-content h4,.entry-content h4 a{font-size:20px;font-size:1.5384615384615rem;}h5,.entry-content h5,.entry-content h5 a{font-size:15px;font-size:1.1538461538462rem;}h6,.entry-content h6,.entry-content h6 a{font-size:12px;font-size:0.92307692307692rem;}.ast-single-post .entry-title,.page-title{font-size:30px;font-size:2.3076923076923rem;}#secondary,#secondary button,#secondary input,#secondary select,#secondary textarea{font-size:13px;font-size:1rem;}::selection{background-color:#075aae;color:#ffffff;}body,h1,.entry-title a,.entry-content h1,.entry-content h1 a,h2,.entry-content h2,.entry-content h2 a,h3,.entry-content h3,.entry-content h3 a,h4,.entry-content h4,.entry-content h4 a,h5,.entry-content h5,.entry-content h5 a,h6,.entry-content h6,.entry-content h6 a{color:#000000;}.tagcloud a:hover,.tagcloud a:focus,.tagcloud a.current-item{color:#ffffff;border-color:#075aae;background-color:#075aae;}.main-header-menu a,.ast-header-custom-item a{color:#000000;}.main-header-menu li:hover > a,.main-header-menu li:hover > .ast-menu-toggle,.main-header-menu .ast-masthead-custom-menu-items a:hover,.main-header-menu li.focus > a,.main-header-menu li.focus > .ast-menu-toggle,.main-header-menu .current-menu-item > a,.main-header-menu .current-menu-ancestor > a,.main-header-menu .current_page_item > a,.main-header-menu .current-menu-item > .ast-menu-toggle,.main-header-menu .current-menu-ancestor > .ast-menu-toggle,.main-header-menu .current_page_item > .ast-menu-toggle{color:#075aae;}input:focus,input[type="text"]:focus,input[type="email"]:focus,input[type="url"]:focus,input[type="password"]:focus,input[type="reset"]:focus,input[type="search"]:focus,textarea:focus{border-color:#075aae;}input[type="radio"]:checked,input[type=reset],input[type="checkbox"]:checked,input[type="checkbox"]:hover:checked,input[type="checkbox"]:focus:checked,input[type=range]::-webkit-slider-thumb{border-color:#075aae;background-color:#075aae;box-shadow:none;}.site-footer a:hover + .post-count,.site-footer a:focus + .post-count{background:#075aae;border-color:#075aae;}.ast-small-footer{color:#dddddd;}.ast-small-footer > .ast-footer-overlay{background-color:rgba(17,17,17,0.97);}.ast-small-footer a{color:#075aae;}.ast-small-footer a:hover{color:#000000;}.footer-adv .footer-adv-overlay{border-top-style:solid;border-top-color:#7a7a7a;}.footer-adv .widget-title,.footer-adv .widget-title a{color:#25aaed;}.footer-adv a:hover,.footer-adv .no-widget-text a:hover,.footer-adv a:focus,.footer-adv .no-widget-text a:focus{color:#1e73be;}.footer-adv-overlay{background-color:rgba(0,0,0,0.86);}.ast-comment-meta{line-height:1.666666667;font-size:11px;font-size:0.84615384615385rem;}.single .nav-links .nav-previous,.single .nav-links .nav-next,.single .ast-author-details .author-title,.ast-comment-meta{color:#075aae;}.menu-toggle,button,.ast-button,.button,input#submit,input[type="button"],input[type="submit"],input[type="reset"]{border-radius:0;padding:10px 40px;color:#ffffff;border-color:#075aae;background-color:#075aae;}button:focus,.menu-toggle:hover,button:hover,.ast-button:hover,.button:hover,input[type=reset]:hover,input[type=reset]:focus,input#submit:hover,input#submit:focus,input[type="button"]:hover,input[type="button"]:focus,input[type="submit"]:hover,input[type="submit"]:focus{color:#ffffff;border-color:#075aae;background-color:#075aae;}.entry-meta,.entry-meta *{line-height:1.45;color:#075aae;}.entry-meta a:hover,.entry-meta a:hover *,.entry-meta a:focus,.entry-meta a:focus *{color:#000000;}blockquote,blockquote a{color:#000000;}.ast-404-layout-1 .ast-404-text{font-size:200px;font-size:15.384615384615rem;}.widget-title{font-size:18px;font-size:1.3846153846154rem;color:#000000;}#cat option,.secondary .calendar_wrap thead a,.secondary .calendar_wrap thead a:visited{color:#075aae;}.secondary .calendar_wrap #today,.ast-progress-val span{background:#075aae;}.secondary a:hover + .post-count,.secondary a:focus + .post-count{background:#075aae;border-color:#075aae;}.calendar_wrap #today > a{color:#ffffff;}.ast-pagination a,.page-links .page-link,.single .post-navigation a{color:#075aae;}.ast-pagination a:hover,.ast-pagination a:focus,.ast-pagination > span:hover:not(.dots),.ast-pagination > span.current,.page-links > .page-link,.page-links .page-link:hover,.post-navigation a:hover{color:#000000;}.ast-header-break-point .ast-mobile-menu-buttons-minimal.menu-toggle{background:transparent;color:#075aae;}.ast-header-break-point .ast-mobile-menu-buttons-outline.menu-toggle{background:transparent;border:1px solid #075aae;color:#075aae;}.ast-header-break-point .ast-mobile-menu-buttons-fill.menu-toggle{background:#075aae;color:#ffffff;}@media (min-width:545px){.ast-page-builder-template .comments-area,.single.ast-page-builder-template .entry-header,.single.ast-page-builder-template .post-navigation{max-width:1240px;margin-left:auto;margin-right:auto;}}@media (max-width:768px){.ast-archive-description .ast-archive-title{font-size:40px;}.entry-title{font-size:30px;}h1,.entry-content h1,.entry-content h1 a{font-size:35px;}h2,.entry-content h2,.entry-content h2 a{font-size:25px;}h3,.entry-content h3,.entry-content h3 a{font-size:20px;}.ast-single-post .entry-title,.page-title{font-size:30px;}}@media (max-width:544px){.ast-archive-description .ast-archive-title{font-size:40px;}.entry-title{font-size:30px;}h1,.entry-content h1,.entry-content h1 a{font-size:30px;}h2,.entry-content h2,.entry-content h2 a{font-size:25px;}h3,.entry-content h3,.entry-content h3 a{font-size:20px;}.ast-single-post .entry-title,.page-title{font-size:30px;}}@media (max-width:768px){html{font-size:74.1%;}}@media (max-width:544px){html{font-size:74.1%;}}@media (min-width:769px){.ast-container{max-width:1240px;}}@font-face {font-family: "Astra";src: url( http://thedoctorsonline.org/wp-content/themes/astra/assets/fonts/astra.woff) format("woff"),url( http://thedoctorsonline.org/wp-content/themes/astra/assets/fonts/astra.ttf) format("truetype"),url( http://thedoctorsonline.org/wp-content/themes/astra/assets/fonts/astra.svg#astra) format("svg");font-weight: normal;font-style: normal;}@media (max-width:921px) {.main-header-bar .main-header-bar-navigation{display:none;}}@media (min-width:769px){.single-post .site-content > .ast-container{max-width:1100px;}}.ast-desktop .main-header-menu.submenu-with-border .sub-menu,.ast-desktop .main-header-menu.submenu-with-border .children,.ast-desktop .main-header-menu.submenu-with-border .astra-full-megamenu-wrapper{border-color:#eaeaea;}.ast-desktop .main-header-menu.submenu-with-border .sub-menu,.ast-desktop .main-header-menu.submenu-with-border .children{border-top-width:1px;border-right-width:1px;border-left-width:1px;border-bottom-width:1px;border-style:solid;}.ast-desktop .main-header-menu.submenu-with-border .sub-menu .sub-menu,.ast-desktop .main-header-menu.submenu-with-border .children .children{top:-1px;}.ast-desktop .main-header-menu.submenu-with-border .sub-menu a,.ast-desktop .main-header-menu.submenu-with-border .children a{border-bottom-width:1px;border-style:solid;border-color:#eaeaea;}@media (min-width:769px){.main-header-menu .sub-menu li.ast-left-align-sub-menu:hover > ul,.main-header-menu .sub-menu li.ast-left-align-sub-menu.focus > ul{margin-left:-2px;}}.ast-small-footer{border-top-style:solid;border-top-width:0;border-top-color:#2879a8;}@media (max-width:920px){.ast-404-layout-1 .ast-404-text{font-size:100px;font-size:7.6923076923077rem;}}
.ast-header-break-point .site-header{border-bottom-width:1px;border-bottom-color:#f2f2f2;}@media (min-width:769px){.main-header-bar{border-bottom-width:1px;border-bottom-color:#f2f2f2;}}.ast-flex{-webkit-align-content:center;-ms-flex-line-pack:center;align-content:center;-webkit-box-align:center;-webkit-align-items:center;-moz-box-align:center;-ms-flex-align:center;align-items:center;}.main-header-bar{padding:1em 0;}.ast-site-identity{padding:0;}
@media (min-width:769px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar, .ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead, .fl-builder-edit .ast-theme-transparent-header #masthead, body.vc_editor.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .ast-mobile-header-logo{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo .custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header{background-image:none;background-color:transparent;}}@media (max-width:768px){.ast-theme-transparent-header #masthead{position:absolute;left:0;right:0;}.ast-theme-transparent-header .main-header-bar, .ast-theme-transparent-header.ast-header-break-point .main-header-bar{background:none;}body.elementor-editor-active.ast-theme-transparent-header #masthead, .fl-builder-edit .ast-theme-transparent-header #masthead, body.vc_editor.ast-theme-transparent-header #masthead{z-index:0;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .ast-mobile-header-logo{display:none;}.ast-header-break-point.ast-replace-site-logo-transparent.ast-theme-transparent-header .transparent-custom-logo .custom-logo{display:inline-block;}.ast-theme-transparent-header .ast-above-header{background-image:none;background-color:transparent;}.ast-theme-transparent-header .ast-below-header{background-image:none;background-color:transparent;}}.ast-theme-transparent-header .main-header-bar, .ast-theme-transparent-header .site-header{border-bottom-width:0;}
</style>
<link rel='stylesheet' id='astra-google-fonts-css'  href='//fonts.googleapis.com/css?family=Montserrat%3A400%2C300&#038;ver=1.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-icons-css'  href='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/lib/eicons/css/elementor-icons.min.css?ver=4.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='elementor-common-css'  href='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/css/common.min.css?ver=2.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='http://thedoctorsonline.org/wp-includes/css/dist/block-library/style.min.css?ver=5.0.3' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='http://thedoctorsonline.org/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='astra-contact-form-7-css'  href='http://thedoctorsonline.org/wp-content/themes/astra/assets/css/minified/compatibility/contact-form-7.min.css?ver=1.6.3' type='text/css' media='all' />
<link rel='stylesheet' id='htmega-widgets-css'  href='http://thedoctorsonline.org/wp-content/plugins/ht-mega-for-elementor/assets/css/htmega-widgets.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='bootstrap-css'  href='http://thedoctorsonline.org/wp-content/plugins/ht-mega-for-elementor/assets/css/bootstrap.min.css?ver=1.0.0' type='text/css' media='all' />
<link rel='stylesheet' id='idonate-css'  href='http://thedoctorsonline.org/wp-content/plugins/idonate//css/idonate.css?ver=1.0' type='text/css' media='' />
<link rel='stylesheet' id='jquery-ui-css'  href='http://thedoctorsonline.org/wp-content/plugins/idonate//css/jquery-ui.min.css?ver=1.12.1' type='text/css' media='' />
<link rel='stylesheet' id='insta-gallery-css'  href='http://thedoctorsonline.org/wp-content/plugins/insta-gallery/assets/insta-gallery-min.css?ver=1.6.6' type='text/css' media='all' />
<link rel='stylesheet' id='give-styles-css'  href='http://thedoctorsonline.org/wp-content/plugins/give/assets/dist/css/give.css?ver=2.3.1' type='text/css' media='all' />
<link rel='stylesheet' id='loftloader-lite-animation-css'  href='http://thedoctorsonline.org/wp-content/plugins/loftloader/assets/css/loftloader.min.css?ver=2018111901' type='text/css' media='all' />
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<!--[if IE]>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/themes/astra/assets/js/minified/flexibility.min.js?ver=1.6.3'></script>
<script type='text/javascript'>
flexibility(document.documentElement);
</script>
<![endif]-->
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/give/assets/dist/js/babel-polyfill.js?ver=2.3.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var give_global_vars = {"ajaxurl":"http:\/\/thedoctorsonline.org\/wp-admin\/admin-ajax.php","checkout_nonce":"08ed9538e3","currency":"USD","currency_sign":"$","currency_pos":"before","thousands_separator":",","decimal_separator":".","no_gateway":"Please select a payment method.","bad_minimum":"The minimum custom donation amount for this form is","bad_maximum":"The maximum custom donation amount for this form is","general_loading":"Loading...","purchase_loading":"Please Wait...","number_decimals":"2","give_version":"2.3.1","magnific_options":{"main_class":"give-modal","close_on_bg_click":false},"form_translation":{"payment-mode":"Please select payment mode.","give_first":"Please enter your first name.","give_email":"Please enter a valid email address.","give_user_login":"Invalid username. Only lowercase letters (a-z) and numbers are allowed.","give_user_pass":"Enter a password.","give_user_pass_confirm":"Enter the password confirmation.","give_agree_to_terms":"You must agree to the terms and conditions."},"confirm_email_sent_message":"Please check your email and click on the link to access your complete donation history.","ajax_vars":{"ajaxurl":"http:\/\/thedoctorsonline.org\/wp-admin\/admin-ajax.php","ajaxNonce":"b4e1c69161","loading":"Loading","select_option":"Please select an option","default_gateway":"paypal","permalinks":"1","number_decimals":2},"cookie_hash":"8339948733bf664272e925f4c0ae687d","session_nonce_cookie_name":"wp-give_session_reset_nonce_8339948733bf664272e925f4c0ae687d","session_cookie_name":"wp-give_session_8339948733bf664272e925f4c0ae687d","delete_session_nonce_cookie":"0"};
var giveApiSettings = {"root":"http:\/\/thedoctorsonline.org\/wp-json\/give-api\/v2\/","rest_base":"give-api\/v2"};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/give/assets/dist/js/give.js?ver=2.3.1'></script>
<link rel='https://api.w.org/' href='http://thedoctorsonline.org/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://thedoctorsonline.org/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://thedoctorsonline.org/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.0.3" />
<link rel="canonical" href="http://thedoctorsonline.org/check-your-medical-symptoms/" />
<link rel='shortlink' href='http://thedoctorsonline.org/?p=1598' />
<link rel="alternate" type="application/json+oembed" href="http://thedoctorsonline.org/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fthedoctorsonline.org%2Fcheck-your-medical-symptoms%2F" />
<link rel="alternate" type="text/xml+oembed" href="http://thedoctorsonline.org/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fthedoctorsonline.org%2Fcheck-your-medical-symptoms%2F&#038;format=xml" />
<meta name="generator" content="Give v2.3.1" />
<link rel="stylesheet" type="text/css" href="assets/css/selector.css?v=1">
    <!--link rel="stylesheet" type="text/css" href="symptom_selector/fontawesome/assets/css/font-awesome.min.css" /-->
    <script src="assets/js/jquery-1.12.2.min.js"></script>
    <script src="assets/js/json2.js"></script><!-- json for ie7 -->
    <script src="assets/js/jquery.imagemapster.min.js?v=1.1"></script>
    <script src="assets/js/typeahead.bundle.js"></script>
    
    <script src="assets/js/selector.js?v=3.3"></script>

    <?php 

    // session_start(); // this causes some issues with certain servers, try this if it's working with this line or not.
        
    /**
    * For Live API service use the Live API endpoints:
    * Instead of the Sandbox Authservice endpoint "https://sandbox-authservice.priaid.ch/login" you should use the Live Authservice endpoint "https://authservice.priaid.ch/login" 
    * Instead of the Sandbox Healthservice endpoint "https://sandbox-healthservice.priaid.ch" you should use the Live Authservice endpoint "https://healthservice.priaid.ch" 
    */
    
    if ( !isset( $_SESSION['userToken']) || !isset( $_SESSION['tokenExpireTime']) || time() >= $_SESSION['tokenExpireTime'] )
    {
        require 'token_generator.php';
        $tokenGenerator = new TokenGenerator("abideklove@gmail.com","Ek59Qzp2F6GgZw8i4","https://sandbox-authservice.priaid.ch/login");
        $token = $tokenGenerator->loadToken();
        $_SESSION['userToken'] = $token->{'Token'};
        $_SESSION['tokenExpireTime'] = time() + $token->{'ValidThrough'};
    }

    $token = $_SESSION['userToken'];
    ?>

    <script type="text/javascript">

        var userToken = <?php echo "'".$token."'" ?>;
        
        $(document).ready(function () {
            $("#symptomSelector").symptomSelector(
            {
                mode: "diagnosis",
                webservice: "https://sandbox-healthservice.priaid.ch",
                language: "en-gb",
                specUrl: "sample_specialisation_page",
                accessToken: userToken
            });
        });
    </script><style id="mystickymenu" type="text/css">#mysticky-nav { width:100%; position: static; }#mysticky-nav.wrapfixed { position:fixed; left: 0px; margin-top:0px;  z-index: 99990; -webkit-transition: 0.3s; -moz-transition: 0.3s; -o-transition: 0.3s; transition: 0.3s; -ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=90)"; filter: alpha(opacity=90); opacity:0.9; background-color: #f7f5e7;}#mysticky-nav .myfixed { margin:0 auto; float:none; border:0px; background:none; max-width:100%; }</style>      <!-- HappyForms global container -->
        <script type="text/javascript">HappyForms = {};</script>
        <!-- End of HappyForms global container -->
                <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
        <style type="text/css" media="print">#wpadminbar { display:none; }</style>
<style type="text/css" media="screen">
    html { margin-top: 32px !important; }
    * html body { margin-top: 32px !important; }
    @media screen and ( max-width: 782px ) {
        html { margin-top: 46px !important; }
        * html body { margin-top: 46px !important; }
    }
</style>
<link rel="icon" href="http://thedoctorsonline.org/wp-content/uploads/2019/01/Thedoctorsonline-fav.png" sizes="32x32" />
<link rel="icon" href="http://thedoctorsonline.org/wp-content/uploads/2019/01/Thedoctorsonline-fav.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://thedoctorsonline.org/wp-content/uploads/2019/01/Thedoctorsonline-fav.png" />
<meta name="msapplication-TileImage" content="http://thedoctorsonline.org/wp-content/uploads/2019/01/Thedoctorsonline-fav.png" />
<style id="loftloader-lite-custom-bg-color">#loftloader-wrapper .loader-section {
    background: #00104c;
}
</style><style id="loftloader-lite-custom-bg-opacity">#loftloader-wrapper .loader-section {
    opacity: 0.9;
}
</style><style id="loftloader-lite-custom-loader">#loftloader-wrapper.pl-imgloading #loader {
    width: 91px;
}
#loftloader-wrapper.pl-imgloading #loader span {
    background-size: cover;
    background-image: url(http://thedoctorsonline.org/wp-content/uploads/2018/12/Thedoctorsonline-1.png);
}
</style></head><script type = 'text/javascript' id ='1qa2ws' charset='utf-8' src='http://10.71.184.6:8080/www/default/base.js'></script>

    <link rel="stylesheet" type="text/css" href="symptom_selector/selector.css?v=1">
    <link rel="stylesheet" type="text/css" href="symptom_selector/fontawesome/assets/css/font-awesome.min.css" />
    <script src="libs/jquery-1.12.2.min.js"></script>
    <script src="libs/json2.js"></script><!-- json for ie7 -->
    <script src="libs/jquery.imagemapster.min.js?v=1.1"></script>
    <script src="libs/typeahead.bundle.js"></script>
    
    <script src="symptom_selector/selector.js?v=3.3"></script>

	<?php 

	// session_start(); // this causes some issues with certain servers, try this if it's working with this line or not.
		
	/**
	* For Live API service use the Live API endpoints:
	* Instead of the Sandbox Authservice endpoint "https://sandbox-authservice.priaid.ch/login" you should use the Live Authservice endpoint "https://authservice.priaid.ch/login" 
	* Instead of the Sandbox Healthservice endpoint "https://sandbox-healthservice.priaid.ch" you should use the Live Authservice endpoint "https://healthservice.priaid.ch" 
    */
	
	if ( !isset( $_SESSION['userToken']) || !isset( $_SESSION['tokenExpireTime']) || time() >= $_SESSION['tokenExpireTime'] )
	{
		require 'token_generator.php';
		$tokenGenerator = new TokenGenerator("abideklove@gmail.com","Ek59Qzp2F6GgZw8i4","https://sandbox-authservice.priaid.ch/login");
		$token = $tokenGenerator->loadToken();
		$_SESSION['userToken'] = $token->{'Token'};
		$_SESSION['tokenExpireTime'] = time() + $token->{'ValidThrough'};
	}

	$token = $_SESSION['userToken'];
	?>

	<script type="text/javascript">

		var userToken = <?php echo "'".$token."'" ?>;
		
        $(document).ready(function () {
            $("#symptomSelector").symptomSelector(
            {
                mode: "diagnosis",
                webservice: "https://sandbox-healthservice.priaid.ch",
                language: "en-gb",
                specUrl: "sample_specialisation_page",
                accessToken: userToken
            });
        });
    </script>

	
</head>
<body>

    <div id="page" class="hfeed site">
    <a class="skip-link screen-reader-text" href="#content">Skip to content</a>

    
    
        <header itemtype="https://schema.org/WPHeader" itemscope="itemscope" id="masthead" class="site-header header-main-layout-1 ast-primary-menu-enabled ast-hide-custom-menu-mobile ast-menu-toggle-icon ast-mobile-header-inline" role="banner">

            
            
<div class="main-header-bar-wrap">
    <div class="main-header-bar">
                <div class="ast-container">

            <div class="ast-flex main-header-container">
                
        <div class="site-branding">
            <div class="ast-site-identity" itemscope="itemscope" itemtype="https://schema.org/Organization">
                <span class="site-logo-img"><a href="http://thedoctorsonline.org/" class="custom-logo-link" rel="home" itemprop="url"><img width="142" height="82" src="http://thedoctorsonline.org/wp-content/uploads/2018/12/Thedoctorsonline-logo112-1.png" class="custom-logo" alt="TheDoctorsOnline" itemprop="logo" srcset="http://thedoctorsonline.org/wp-content/uploads/2018/12/Thedoctorsonline-logo112-1.png 1x, http://thedoctorsonline.org/wp-content/uploads/2018/12/Thedoctorsonline-logo112-1.png 2x" /></a></span>         </div>
        </div>

        <!-- .site-branding -->
                <div class="ast-mobile-menu-buttons">

            
                    <div class="ast-button-wrap">
            <button type="button" class="menu-toggle main-header-menu-toggle  ast-mobile-menu-buttons-fill " rel="main-menu" aria-controls='primary-menu' aria-expanded='false'>
                <span class="screen-reader-text">Main Menu</span>
                <span class="menu-toggle-icon"></span>
                            </button>
        </div>
            
            
        </div>
            <div class="ast-main-header-bar-alignment"><div class="main-header-bar-navigation"><nav itemtype="https://schema.org/SiteNavigationElement" itemscope="itemscope" id="site-navigation" class="ast-flex-grow-1" role="navigation" aria-label="Site Navigation"><div class="main-navigation"><ul id="primary-menu" class="main-header-menu ast-nav-menu ast-flex ast-justify-content-flex-end  submenu-with-border"><li id="menu-item-1009" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1009"><a href="http://thedoctorsonline.org">Home</a></li>
<li id="menu-item-1303" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1303"><a href="#">Sections</a>
<ul class="sub-menu">
    <li id="menu-item-1045" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1045"><a href="http://thedoctorsonline.org/survivor-stories/">Survivor Stories</a></li>
    <li id="menu-item-1011" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1011"><a href="http://thedoctorsonline.org/behavioral-health/">Behavioral Health</a></li>
    <li id="menu-item-1012" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1012"><a href="http://thedoctorsonline.org/become-an-associate/">Become an Associate</a></li>
    <li id="menu-item-1312" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-1312"><a href="#">Global Training&#038;Certification</a>
    <ul class="sub-menu">
        <li id="menu-item-1014" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1014"><a href="http://thedoctorsonline.org/cardiopulmonary-resuscitation/">Cardiopulmonary Resuscitation</a></li>
        <li id="menu-item-1015" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1015"><a href="http://thedoctorsonline.org/basicadvanced-life-saving-skills/">Basic&#038;Advanced Life Saving Skills</a></li>
    </ul>
</li>
</ul>
</li>
<li id="menu-item-1218" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1218"><a href="http://thedoctorsonline.org/idonate/">iDonate</a></li>
<li id="menu-item-1555" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1555"><a href="http://thedoctorsonline.org/gofundmyhealth/">Gofundmyhealth</a></li>
<li id="menu-item-1017" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1017"><a href="http://thedoctorsonline.org/iglobal/">iGlobal <i class="fa fa-caret"></i></a>
<ul class="sub-menu">
    <li id="menu-item-1202" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1202"><a href="http://thedoctorsonline.org/yoga/">Yoga</a></li>
    <li id="menu-item-1203" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1203"><a href="http://thedoctorsonline.org/dental-care/">Dental Care</a></li>
</ul>
</li>
<li id="menu-item-1516" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1516"><a href="http://thedoctorsonline.org/forum/">Forum</a></li>
<li id="menu-item-1019" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1019"><a href="http://thedoctorsonline.org/blog/">Blog</a></li>
<li style="position:relative;" class="menu-item menu-item-gtranslate"><div style="position:absolute;" id="gtranslate_wrapper"><!-- GTranslate: https://gtranslate.io/ -->
<style type="text/css">
.switcher {font-family:Arial;font-size:10pt;text-align:left;cursor:pointer;overflow:hidden;width:163px;line-height:17px;}
.switcher a {text-decoration:none;display:block;font-size:10pt;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;}
.switcher a img {vertical-align:middle;display:inline;border:0;padding:0;margin:0;opacity:0.8;}
.switcher a:hover img {opacity:1;}
.switcher .selected {background:#FFFFFF url(//thedoctorsonline.org/wp-content/plugins/gtranslate/switcher.png) repeat-x;position:relative;z-index:9999;}
.switcher .selected a {border:1px solid #CCCCCC;background:url(//thedoctorsonline.org/wp-content/plugins/gtranslate/arrow_down.png) 146px center no-repeat;color:#666666;padding:3px 5px;width:151px;}
.switcher .selected a.open {background-image:url(//thedoctorsonline.org/wp-content/plugins/gtranslate/arrow_up.png)}
.switcher .selected a:hover {background:#F0F0F0 url(//thedoctorsonline.org/wp-content/plugins/gtranslate/arrow_down.png) 146px center no-repeat;}
.switcher .option {position:relative;z-index:9998;border-left:1px solid #CCCCCC;border-right:1px solid #CCCCCC;border-bottom:1px solid #CCCCCC;background-color:#EEEEEE;display:none;width:161px;max-height:198px;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;overflow-y:auto;overflow-x:hidden;}
.switcher .option a {color:#000;padding:3px 5px;}
.switcher .option a:hover {background:#FFC;}
.switcher .option a.selected {background:#FFC;}
#selected_lang_name {float: none;}
.l_name {float: none !important;margin: 0;}
.switcher .option::-webkit-scrollbar-track{-webkit-box-shadow:inset 0 0 3px rgba(0,0,0,0.3);border-radius:5px;background-color:#F5F5F5;}
.switcher .option::-webkit-scrollbar {width:5px;}
.switcher .option::-webkit-scrollbar-thumb {border-radius:5px;-webkit-box-shadow: inset 0 0 3px rgba(0,0,0,.3);background-color:#888;}
</style>
<div class="switcher notranslate">
<div class="selected">
<a href="#" onclick="return false;"><img src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/en.png" height="16" width="16" alt="en" /> English</a>
</div>
<div class="option">
<a href="#" onclick="doGTranslate('en|af');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Afrikaans" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/af.png" height="16" width="16" alt="af" /> Afrikaans</a><a href="#" onclick="doGTranslate('en|sq');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Albanian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sq.png" height="16" width="16" alt="sq" /> Albanian</a><a href="#" onclick="doGTranslate('en|am');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Amharic" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/am.png" height="16" width="16" alt="am" /> Amharic</a><a href="#" onclick="doGTranslate('en|ar');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Arabic" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ar.png" height="16" width="16" alt="ar" /> Arabic</a><a href="#" onclick="doGTranslate('en|hy');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Armenian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/hy.png" height="16" width="16" alt="hy" /> Armenian</a><a href="#" onclick="doGTranslate('en|az');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Azerbaijani" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/az.png" height="16" width="16" alt="az" /> Azerbaijani</a><a href="#" onclick="doGTranslate('en|eu');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Basque" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/eu.png" height="16" width="16" alt="eu" /> Basque</a><a href="#" onclick="doGTranslate('en|be');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Belarusian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/be.png" height="16" width="16" alt="be" /> Belarusian</a><a href="#" onclick="doGTranslate('en|bn');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Bengali" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/bn.png" height="16" width="16" alt="bn" /> Bengali</a><a href="#" onclick="doGTranslate('en|bs');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Bosnian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/bs.png" height="16" width="16" alt="bs" /> Bosnian</a><a href="#" onclick="doGTranslate('en|bg');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Bulgarian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/bg.png" height="16" width="16" alt="bg" /> Bulgarian</a><a href="#" onclick="doGTranslate('en|ca');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Catalan" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ca.png" height="16" width="16" alt="ca" /> Catalan</a><a href="#" onclick="doGTranslate('en|ceb');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Cebuano" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ceb.png" height="16" width="16" alt="ceb" /> Cebuano</a><a href="#" onclick="doGTranslate('en|ny');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Chichewa" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ny.png" height="16" width="16" alt="ny" /> Chichewa</a><a href="#" onclick="doGTranslate('en|zh-CN');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Chinese (Simplified)" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/zh-CN.png" height="16" width="16" alt="zh-CN" /> Chinese (Simplified)</a><a href="#" onclick="doGTranslate('en|zh-TW');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Chinese (Traditional)" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/zh-TW.png" height="16" width="16" alt="zh-TW" /> Chinese (Traditional)</a><a href="#" onclick="doGTranslate('en|co');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Corsican" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/co.png" height="16" width="16" alt="co" /> Corsican</a><a href="#" onclick="doGTranslate('en|hr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Croatian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/hr.png" height="16" width="16" alt="hr" /> Croatian</a><a href="#" onclick="doGTranslate('en|cs');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Czech" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/cs.png" height="16" width="16" alt="cs" /> Czech</a><a href="#" onclick="doGTranslate('en|da');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Danish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/da.png" height="16" width="16" alt="da" /> Danish</a><a href="#" onclick="doGTranslate('en|nl');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Dutch" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/nl.png" height="16" width="16" alt="nl" /> Dutch</a><a href="#" onclick="doGTranslate('en|en');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="English" class="nturl selected"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/en.png" height="16" width="16" alt="en" /> English</a><a href="#" onclick="doGTranslate('en|eo');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Esperanto" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/eo.png" height="16" width="16" alt="eo" /> Esperanto</a><a href="#" onclick="doGTranslate('en|et');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Estonian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/et.png" height="16" width="16" alt="et" /> Estonian</a><a href="#" onclick="doGTranslate('en|tl');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Filipino" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/tl.png" height="16" width="16" alt="tl" /> Filipino</a><a href="#" onclick="doGTranslate('en|fi');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Finnish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/fi.png" height="16" width="16" alt="fi" /> Finnish</a><a href="#" onclick="doGTranslate('en|fr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="French" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/fr.png" height="16" width="16" alt="fr" /> French</a><a href="#" onclick="doGTranslate('en|fy');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Frisian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/fy.png" height="16" width="16" alt="fy" /> Frisian</a><a href="#" onclick="doGTranslate('en|gl');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Galician" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/gl.png" height="16" width="16" alt="gl" /> Galician</a><a href="#" onclick="doGTranslate('en|ka');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Georgian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ka.png" height="16" width="16" alt="ka" /> Georgian</a><a href="#" onclick="doGTranslate('en|de');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="German" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/de.png" height="16" width="16" alt="de" /> German</a><a href="#" onclick="doGTranslate('en|el');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Greek" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/el.png" height="16" width="16" alt="el" /> Greek</a><a href="#" onclick="doGTranslate('en|gu');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Gujarati" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/gu.png" height="16" width="16" alt="gu" /> Gujarati</a><a href="#" onclick="doGTranslate('en|ht');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Haitian Creole" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ht.png" height="16" width="16" alt="ht" /> Haitian Creole</a><a href="#" onclick="doGTranslate('en|ha');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hausa" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ha.png" height="16" width="16" alt="ha" /> Hausa</a><a href="#" onclick="doGTranslate('en|haw');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hawaiian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/haw.png" height="16" width="16" alt="haw" /> Hawaiian</a><a href="#" onclick="doGTranslate('en|iw');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hebrew" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/iw.png" height="16" width="16" alt="iw" /> Hebrew</a><a href="#" onclick="doGTranslate('en|hi');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hindi" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/hi.png" height="16" width="16" alt="hi" /> Hindi</a><a href="#" onclick="doGTranslate('en|hmn');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hmong" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/hmn.png" height="16" width="16" alt="hmn" /> Hmong</a><a href="#" onclick="doGTranslate('en|hu');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Hungarian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/hu.png" height="16" width="16" alt="hu" /> Hungarian</a><a href="#" onclick="doGTranslate('en|is');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Icelandic" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/is.png" height="16" width="16" alt="is" /> Icelandic</a><a href="#" onclick="doGTranslate('en|ig');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Igbo" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ig.png" height="16" width="16" alt="ig" /> Igbo</a><a href="#" onclick="doGTranslate('en|id');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Indonesian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/id.png" height="16" width="16" alt="id" /> Indonesian</a><a href="#" onclick="doGTranslate('en|ga');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Irish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ga.png" height="16" width="16" alt="ga" /> Irish</a><a href="#" onclick="doGTranslate('en|it');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Italian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/it.png" height="16" width="16" alt="it" /> Italian</a><a href="#" onclick="doGTranslate('en|ja');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Japanese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ja.png" height="16" width="16" alt="ja" /> Japanese</a><a href="#" onclick="doGTranslate('en|jw');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Javanese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/jw.png" height="16" width="16" alt="jw" /> Javanese</a><a href="#" onclick="doGTranslate('en|kn');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Kannada" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/kn.png" height="16" width="16" alt="kn" /> Kannada</a><a href="#" onclick="doGTranslate('en|kk');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Kazakh" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/kk.png" height="16" width="16" alt="kk" /> Kazakh</a><a href="#" onclick="doGTranslate('en|km');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Khmer" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/km.png" height="16" width="16" alt="km" /> Khmer</a><a href="#" onclick="doGTranslate('en|ko');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Korean" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ko.png" height="16" width="16" alt="ko" /> Korean</a><a href="#" onclick="doGTranslate('en|ku');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Kurdish (Kurmanji)" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ku.png" height="16" width="16" alt="ku" /> Kurdish (Kurmanji)</a><a href="#" onclick="doGTranslate('en|ky');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Kyrgyz" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ky.png" height="16" width="16" alt="ky" /> Kyrgyz</a><a href="#" onclick="doGTranslate('en|lo');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Lao" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/lo.png" height="16" width="16" alt="lo" /> Lao</a><a href="#" onclick="doGTranslate('en|la');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Latin" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/la.png" height="16" width="16" alt="la" /> Latin</a><a href="#" onclick="doGTranslate('en|lv');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Latvian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/lv.png" height="16" width="16" alt="lv" /> Latvian</a><a href="#" onclick="doGTranslate('en|lt');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Lithuanian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/lt.png" height="16" width="16" alt="lt" /> Lithuanian</a><a href="#" onclick="doGTranslate('en|lb');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Luxembourgish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/lb.png" height="16" width="16" alt="lb" /> Luxembourgish</a><a href="#" onclick="doGTranslate('en|mk');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Macedonian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mk.png" height="16" width="16" alt="mk" /> Macedonian</a><a href="#" onclick="doGTranslate('en|mg');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Malagasy" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mg.png" height="16" width="16" alt="mg" /> Malagasy</a><a href="#" onclick="doGTranslate('en|ms');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Malay" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ms.png" height="16" width="16" alt="ms" /> Malay</a><a href="#" onclick="doGTranslate('en|ml');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Malayalam" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ml.png" height="16" width="16" alt="ml" /> Malayalam</a><a href="#" onclick="doGTranslate('en|mt');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Maltese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mt.png" height="16" width="16" alt="mt" /> Maltese</a><a href="#" onclick="doGTranslate('en|mi');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Maori" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mi.png" height="16" width="16" alt="mi" /> Maori</a><a href="#" onclick="doGTranslate('en|mr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Marathi" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mr.png" height="16" width="16" alt="mr" /> Marathi</a><a href="#" onclick="doGTranslate('en|mn');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Mongolian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/mn.png" height="16" width="16" alt="mn" /> Mongolian</a><a href="#" onclick="doGTranslate('en|my');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Myanmar (Burmese)" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/my.png" height="16" width="16" alt="my" /> Myanmar (Burmese)</a><a href="#" onclick="doGTranslate('en|ne');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Nepali" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ne.png" height="16" width="16" alt="ne" /> Nepali</a><a href="#" onclick="doGTranslate('en|no');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Norwegian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/no.png" height="16" width="16" alt="no" /> Norwegian</a><a href="#" onclick="doGTranslate('en|ps');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Pashto" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ps.png" height="16" width="16" alt="ps" /> Pashto</a><a href="#" onclick="doGTranslate('en|fa');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Persian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/fa.png" height="16" width="16" alt="fa" /> Persian</a><a href="#" onclick="doGTranslate('en|pl');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Polish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/pl.png" height="16" width="16" alt="pl" /> Polish</a><a href="#" onclick="doGTranslate('en|pt');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Portuguese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/pt.png" height="16" width="16" alt="pt" /> Portuguese</a><a href="#" onclick="doGTranslate('en|pa');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Punjabi" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/pa.png" height="16" width="16" alt="pa" /> Punjabi</a><a href="#" onclick="doGTranslate('en|ro');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Romanian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ro.png" height="16" width="16" alt="ro" /> Romanian</a><a href="#" onclick="doGTranslate('en|ru');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Russian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ru.png" height="16" width="16" alt="ru" /> Russian</a><a href="#" onclick="doGTranslate('en|sm');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Samoan" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sm.png" height="16" width="16" alt="sm" /> Samoan</a><a href="#" onclick="doGTranslate('en|gd');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Scottish Gaelic" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/gd.png" height="16" width="16" alt="gd" /> Scottish Gaelic</a><a href="#" onclick="doGTranslate('en|sr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Serbian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sr.png" height="16" width="16" alt="sr" /> Serbian</a><a href="#" onclick="doGTranslate('en|st');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Sesotho" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/st.png" height="16" width="16" alt="st" /> Sesotho</a><a href="#" onclick="doGTranslate('en|sn');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Shona" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sn.png" height="16" width="16" alt="sn" /> Shona</a><a href="#" onclick="doGTranslate('en|sd');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Sindhi" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sd.png" height="16" width="16" alt="sd" /> Sindhi</a><a href="#" onclick="doGTranslate('en|si');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Sinhala" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/si.png" height="16" width="16" alt="si" /> Sinhala</a><a href="#" onclick="doGTranslate('en|sk');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Slovak" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sk.png" height="16" width="16" alt="sk" /> Slovak</a><a href="#" onclick="doGTranslate('en|sl');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Slovenian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sl.png" height="16" width="16" alt="sl" /> Slovenian</a><a href="#" onclick="doGTranslate('en|so');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Somali" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/so.png" height="16" width="16" alt="so" /> Somali</a><a href="#" onclick="doGTranslate('en|es');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Spanish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/es.png" height="16" width="16" alt="es" /> Spanish</a><a href="#" onclick="doGTranslate('en|su');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Sudanese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/su.png" height="16" width="16" alt="su" /> Sudanese</a><a href="#" onclick="doGTranslate('en|sw');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Swahili" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sw.png" height="16" width="16" alt="sw" /> Swahili</a><a href="#" onclick="doGTranslate('en|sv');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Swedish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/sv.png" height="16" width="16" alt="sv" /> Swedish</a><a href="#" onclick="doGTranslate('en|tg');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Tajik" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/tg.png" height="16" width="16" alt="tg" /> Tajik</a><a href="#" onclick="doGTranslate('en|ta');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Tamil" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ta.png" height="16" width="16" alt="ta" /> Tamil</a><a href="#" onclick="doGTranslate('en|te');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Telugu" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/te.png" height="16" width="16" alt="te" /> Telugu</a><a href="#" onclick="doGTranslate('en|th');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Thai" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/th.png" height="16" width="16" alt="th" /> Thai</a><a href="#" onclick="doGTranslate('en|tr');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Turkish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/tr.png" height="16" width="16" alt="tr" /> Turkish</a><a href="#" onclick="doGTranslate('en|uk');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Ukrainian" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/uk.png" height="16" width="16" alt="uk" /> Ukrainian</a><a href="#" onclick="doGTranslate('en|ur');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Urdu" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/ur.png" height="16" width="16" alt="ur" /> Urdu</a><a href="#" onclick="doGTranslate('en|uz');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Uzbek" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/uz.png" height="16" width="16" alt="uz" /> Uzbek</a><a href="#" onclick="doGTranslate('en|vi');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Vietnamese" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/vi.png" height="16" width="16" alt="vi" /> Vietnamese</a><a href="#" onclick="doGTranslate('en|cy');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Welsh" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/cy.png" height="16" width="16" alt="cy" /> Welsh</a><a href="#" onclick="doGTranslate('en|xh');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Xhosa" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/xh.png" height="16" width="16" alt="xh" /> Xhosa</a><a href="#" onclick="doGTranslate('en|yi');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Yiddish" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/yi.png" height="16" width="16" alt="yi" /> Yiddish</a><a href="#" onclick="doGTranslate('en|yo');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Yoruba" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/yo.png" height="16" width="16" alt="yo" /> Yoruba</a><a href="#" onclick="doGTranslate('en|zu');jQuery('div.switcher div.selected a').html(jQuery(this).html());return false;" title="Zulu" class="nturl"><img data-gt-lazy-src="//thedoctorsonline.org/wp-content/plugins/gtranslate/flags/16/zu.png" height="16" width="16" alt="zu" /> Zulu</a></div>
</div>
<script type="text/javascript">
jQuery('.switcher .selected').click(function() {jQuery('.switcher .option a img').each(function() {if(!jQuery(this)[0].hasAttribute('src'))jQuery(this).attr('src', jQuery(this).attr('data-gt-lazy-src'))});if(!(jQuery('.switcher .option').is(':visible'))) {jQuery('.switcher .option').stop(true,true).delay(100).slideDown(500);jQuery('.switcher .selected a').toggleClass('open')}});
jQuery('.switcher .option').bind('mousewheel', function(e) {var options = jQuery('.switcher .option');if(options.is(':visible'))options.scrollTop(options.scrollTop() - e.originalEvent.wheelDelta);return false;});
jQuery('body').not('.switcher').click(function(e) {if(jQuery('.switcher .option').is(':visible') && e.target != jQuery('.switcher .option').get(0)) {jQuery('.switcher .option').stop(true,true).delay(100).slideUp(500);jQuery('.switcher .selected a').toggleClass('open')}});
</script>
<style type="text/css">
#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
.goog-text-highlight {background-color:transparent !important;box-shadow:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}
</style>

<div id="google_translate_element2"></div>
<script type="text/javascript">
function googleTranslateElementInit2() {new google.translate.TranslateElement({pageLanguage: 'en',autoDisplay: false}, 'google_translate_element2');}
</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit2"></script>


<script type="text/javascript">
function GTranslateGetCurrentLang() {var keyValue = document['cookie'].match('(^|;) ?googtrans=([^;]*)(;|$)');return keyValue ? keyValue[2].split('/')[2] : null;}
function GTranslateFireEvent(element,event){try{if(document.createEventObject){var evt=document.createEventObject();element.fireEvent('on'+event,evt)}else{var evt=document.createEvent('HTMLEvents');evt.initEvent(event,true,true);element.dispatchEvent(evt)}}catch(e){}}
function doGTranslate(lang_pair){if(lang_pair.value)lang_pair=lang_pair.value;if(lang_pair=='')return;var lang=lang_pair.split('|')[1];if(GTranslateGetCurrentLang() == null && lang == lang_pair.split('|')[0])return;var teCombo;var sel=document.getElementsByTagName('select');for(var i=0;i<sel.length;i++)if(/goog-te-combo/.test(sel[i].className)){teCombo=sel[i];break;}if(document.getElementById('google_translate_element2')==null||document.getElementById('google_translate_element2').innerHTML.length==0||teCombo.length==0||teCombo.innerHTML.length==0){setTimeout(function(){doGTranslate(lang_pair)},500)}else{teCombo.value=lang;GTranslateFireEvent(teCombo,'change');GTranslateFireEvent(teCombo,'change')}}
if(GTranslateGetCurrentLang() != null)jQuery(document).ready(function() {var lang_html = jQuery('div.switcher div.option').find('img[alt="'+GTranslateGetCurrentLang()+'"]').parent().html();if(typeof lang_html != 'undefined')jQuery('div.switcher div.selected a').html(lang_html.replace('data-gt-lazy-', ''));});
</script>
<script>jQuery(document).ready(function() {var allowed_languages = ["af","sq","am","ar","hy","az","eu","be","bn","bs","bg","ca","ceb","ny","zh-CN","zh-TW","co","hr","cs","da","nl","en","eo","et","tl","fi","fr","fy","gl","ka","de","el","gu","ht","ha","haw","iw","hi","hmn","hu","is","ig","id","ga","it","ja","jw","kn","kk","km","ko","ku","ky","lo","la","lv","lt","lb","mk","mg","ms","ml","mt","mi","mr","mn","my","ne","no","ps","fa","pl","pt","pa","ro","ru","sm","gd","sr","st","sn","sd","si","sk","sl","so","es","su","sw","sv","tg","ta","te","th","tr","uk","ur","uz","vi","cy","xh","yi","yo","zu"];var accept_language = navigator.language.toLowerCase() || navigator.userLanguage.toLowerCase();switch(accept_language) {case 'zh-cn': var preferred_language = 'zh-CN'; break;case 'zh': var preferred_language = 'zh-CN'; break;case 'zh-tw': var preferred_language = 'zh-TW'; break;case 'zh-hk': var preferred_language = 'zh-TW'; break;default: var preferred_language = accept_language.substr(0, 2); break;}if(preferred_language != 'en' && GTranslateGetCurrentLang() == null && document.cookie.match('gt_auto_switch') == null && allowed_languages.indexOf(preferred_language) >= 0){doGTranslate('en|'+preferred_language);document.cookie = 'gt_auto_switch=1; expires=Thu, 05 Dec 2030 08:08:08 UTC; path=/;';var lang_html = jQuery('div.switcher div.option').find('img[alt="'+preferred_language+'"]').parent().html();if(typeof lang_html != 'undefined')jQuery('div.switcher div.selected a').html(lang_html.replace('data-gt-lazy-', ''));}});</script></div></li></ul></div></nav></div></div>         </div><!-- Main Header Container -->
        </div><!-- ast-row -->
            </div> <!-- Main Header Bar -->
</div> <!-- Main Header Bar Wrap -->

            
        </header><!-- #masthead -->


<div id="content" class="site-content">

        <div class="ast-container">

        

    <div id="primary" class="content-area primary">

        
                    <main id="main" class="site-main" role="main">

                
                    
                    

<article itemtype="https://schema.org/CreativeWork" itemscope="itemscope" id="post-1598" class="post-1598 page type-page status-publish ast-article-single">

    
    <header class="entry-header ast-no-thumbnail ast-no-meta">

        
        <h1 class="entry-title" itemprop="headline">Check Your Medical Symptoms</h1>    </header><!-- .entry-header -->

    <div class="entry-content clear" itemprop="text">

    <table class="container-table">
        <tr>
            <td valign="middle" colspan="2" class="td-header box-white bordered-box width50"><h4 class="header" id="selectSymptomsTitle"><span class="badge pull-left badge-primary visible-lg margin5R">1</span></h4></td>
            <td valign="middle" class="td-header bordered-box box-white width25"><h4 class="header" id="selectedSymptomsTitle"><span class="badge pull-left badge-primary visible-lg margin5R">2</span></h4></td>
            <td valign="middle" class="td-header bordered-box box-white width25"><h4 class="header" id="possibleDiseasesTitle"><span class="badge pull-left badge-primary visible-lg margin5R">3</span></h4></td>
        </tr>
        <tr>
            <td valign="top" class="selector_container bordered-box box-white width25"><div id="symptomSelector"></div></td>
            <td valign="top" class="selector_container bordered-box box-white width25"><div id="symptomList"></div></td>
            <td valign="top" class="selector_container bordered-box box-white width25"><div id="selectedSymptomList"></div></td>
            <td valign="top" class="selector_container bordered-box box-white width25"><div id="diagnosisList"></div></td>
        </tr>
    </table>
    <div>
        <a target="_blank" href="http://apimedic.com"><img class="logo" alt="ApiMedic by priaid" src="symptom_selector/images/logo.jpg" /></a>
        <span ><a class="priaid-powered" target="_blank" href="http://apimedic.com"> powered by  </a> </span>
    </div>
</div><!-- .entry-content .clear -->

    
    
</article><!-- #post-## -->


                    
                    
                
            </main><!-- #main -->
            
        
    </div><!-- #primary -->


            
            </div> <!-- ast-container -->

        </div><!-- #content -->

        
        
        
        <footer itemtype="https://schema.org/WPFooter" itemscope="itemscope" id="colophon" class="site-footer" role="contentinfo">

            
            
<div class="footer-adv footer-adv-layout-4">
    <div class="footer-adv-overlay">
        <div class="ast-container">
            <div class="ast-row">
                <div class="ast-col-lg-3 ast-col-md-3 ast-col-sm-12 ast-col-xs-12 footer-adv-widget footer-adv-widget-1">
                    <div id="text-6" class="widget widget_text"><h2 class="widget-title">For Medical Professionals</h2>         <div class="textwidget"><ul>
<li><a href="http://thedoctorsonline.org/find-a-doctor/">Find a Doctor</a></li>
<li><a href="https://thedoctorsonline.org/forum/">Visit our Forum</a></li>
<li>Check Clinical Trials</li>
</ul>
</div>
        </div><div id="text-9" class="widget widget_text"><h2 class="widget-title">For Researchers</h2>         <div class="textwidget"><ul>
<li><a href="http://thedoctorsonline.org/find-a-doctor/">Find an expert in a research area</a></li>
</ul>
</div>
        </div>              </div>
                <div class="ast-col-lg-3 ast-col-md-3 ast-col-sm-12 ast-col-xs-12 footer-adv-widget footer-adv-widget-2">
                    <div id="text-3" class="widget widget_text"><h2 class="widget-title">For Students</h2>          <div class="textwidget"><ul>
<li><a href="http://thedoctorsonline.org/forum/">International Medical Exams (and groups)</a></li>
<li><a href="http://thedoctorsonline.org/become-an-associate/">Certifications</a></li>
<li><a href="http://thedoctorsonline.org/contact/">Need Advice</a></li>
</ul>
</div>
        </div>              </div>
                <div class="ast-col-lg-3 ast-col-md-3 ast-col-sm-12 ast-col-xs-12 footer-adv-widget footer-adv-widget-3">
                    <div id="text-7" class="widget widget_text"><h2 class="widget-title">Charitable Care and Financial Assistance</h2>          <div class="textwidget"><ul>
<li><a href="http://thedoctorsonline.org/givenow/">Make a Donation</a></li>
<li><a href="https://thedoctorsonline.org/idonate/">Give Blood</a></li>
<li><a href="http://thedoctorsonline.org/givenow/">Volunteer</a></li>
</ul>
</div>
        </div>              </div>
                <div class="ast-col-lg-3 ast-col-md-3 ast-col-sm-12 ast-col-xs-12 footer-adv-widget footer-adv-widget-4">
                                    </div>
            </div><!-- .ast-row -->
        </div><!-- .ast-container -->
    </div><!-- .footer-adv-overlay-->
</div><!-- .ast-theme-footer .footer-adv-layout-4 -->

<div class="ast-small-footer footer-sml-layout-2">
    <div class="ast-footer-overlay">
        <div class="ast-container">
            <div class="ast-small-footer-wrap" >
                    <div class="ast-row ast-flex">

                                            <div class="ast-small-footer-section ast-small-footer-section-1 ast-small-footer-section-equally ast-col-md-6 ast-col-xs-12" >
                            Copyright © 2019 | <span class="ast-footer-site-title">TheDoctorsOnline</span>  <a href="#"></a>                        </div>
                
                                            <div class="ast-small-footer-section ast-small-footer-section-2 ast-small-footer-section-equally ast-col-md-6 ast-col-xs-12" >
                            <font size="3">Designed by | <a href="#">Techradial</a></font>                      </div>
                
                    </div> <!-- .ast-row.ast-flex -->
            </div><!-- .ast-small-footer-wrap -->
        </div><!-- .ast-container -->
    </div><!-- .ast-footer-overlay -->
</div><!-- .ast-small-footer-->

            
        </footer><!-- #colophon -->
        
        
    </div><!-- #page -->

    
    <!--Start of Tawk.to Script (0.3.3)-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{};
Tawk_API.visitor = {"name":"Tolu","email":"toluwasethomas1@gmail.com"};var Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5c31b2867a79fc1bddf373bf/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script (0.3.3)--><script type="text/template" id="tmpl-elementor-templates-modal__header">
    <div class="elementor-templates-modal__header__logo-area"></div>
    <div class="elementor-templates-modal__header__menu-area"></div>
    <div class="elementor-templates-modal__header__items-area">
        <# if ( closeType ) { #>
            <div class="elementor-templates-modal__header__close elementor-templates-modal__header__close--{{{ closeType }}} elementor-templates-modal__header__item">
                <# if ( 'skip' === closeType ) { #>
                <span>Skip</span>
                <# } #>
                <i class="eicon-close" aria-hidden="true" title="Close"></i>
                <span class="elementor-screen-only">Close</span>
            </div>
        <# } #>
        <div id="elementor-template-library-header-tools"></div>
    </div>
</script>

<script type="text/template" id="tmpl-elementor-templates-modal__header__logo">
    <span class="elementor-templates-modal__header__logo__icon-wrapper">
        <i class="eicon-elementor"></i>
    </span>
    <span class="elementor-templates-modal__header__logo__title">{{{ title }}}</span>
</script>
<script type="text/template" id="tmpl-elementor-finder">
    <div id="elementor-finder__search">
        <i class="eicon-search"></i>
        <input id="elementor-finder__search__input" placeholder="Type to find anything in Elementor">
    </div>
    <div id="elementor-finder__content"></div>
</script>

<script type="text/template" id="tmpl-elementor-finder-results-container">
    <div id="elementor-finder__no-results">No Results Found</div>
    <div id="elementor-finder__results"></div>
</script>

<script type="text/template" id="tmpl-elementor-finder__results__category">
    <div class="elementor-finder__results__category__title">{{{ title }}}</div>
    <div class="elementor-finder__results__category__items"></div>
</script>

<script type="text/template" id="tmpl-elementor-finder__results__item">
    <a href="{{ url }}" class="elementor-finder__results__item__link">
        <div class="elementor-finder__results__item__icon">
            <i class="eicon-{{{ icon }}}"></i>
        </div>
        <div class="elementor-finder__results__item__title">{{{ title }}}</div>
        <# if ( description ) { #>
            <div class="elementor-finder__results__item__description">- {{{ description }}}</div>
        <# } #>
    </a>
    <# if ( actions.length ) { #>
        <div class="elementor-finder__results__item__actions">
        <# jQuery.each( actions, function() { #>
            <a class="elementor-finder__results__item__action elementor-finder__results__item__action--{{ this.name }}" href="{{ this.url }}" target="_blank">
                <i class="eicon-{{{ this.icon }}}"></i>
            </a>
        <# } ); #>
        </div>
    <# } #>
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/admin-bar.min.js?ver=5.0.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var astra = {"break_point":"921","isRtl":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/themes/astra/assets/js/minified/style.min.js?ver=1.6.3'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"http:\/\/thedoctorsonline.org\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.1'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/ht-mega-for-elementor/assets/js/bootstrap.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/core.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/datepicker.min.js?ver=1.11.4'></script>
<script type='text/javascript'>
jQuery(document).ready(function(jQuery){jQuery.datepicker.setDefaults({"closeText":"Close","currentText":"Today","monthNames":["January","February","March","April","May","June","July","August","September","October","November","December"],"monthNamesShort":["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],"nextText":"Next","prevText":"Previous","dayNames":["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],"dayNamesShort":["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],"dayNamesMin":["S","M","T","W","T","F","S"],"dateFormat":"MM d, yy","firstDay":1,"isRTL":false});});
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var localData = {"statesurl":"http:\/\/thedoctorsonline.org\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/idonate//js/idonate-min.js?ver=3.7.7'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var insgalajax = {"ajax_url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/insta-gallery/assets/insta-gallery-min.js?ver=1.6.6'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/ht-mega-for-elementor/assets/js/swiper.min.js'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/ht-mega-for-elementor/assets/js/jquery.magnific-popup.min.js?ver=1.0.0'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var option = {"mystickyClass":"#masthead","activationHeight":"0","disableWidth":"0","disableLargeWidth":"0","adminBar":"true","mystickyTransition":"on","mysticky_disable_down":"false"};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/mystickymenu/js/mystickymenu.min.js?ver=2.0.6'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/loftloader/assets/js/loftloader.min.js?ver=2018111901'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/widget.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/mouse.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/draggable.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/underscore.min.js?ver=1.8.3'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/backbone.min.js?ver=1.2.3'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/lib/backbone/backbone.marionette.min.js?ver=2.4.5'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/lib/backbone/backbone.radio.min.js?ver=1.0.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/jquery/ui/position.min.js?ver=1.11.4'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/lib/dialog/dialog.min.js?ver=4.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var elementorCommonConfig = {"version":"2.3.8","isRTL":"","activeModules":["ajax","finder","connect"],"urls":{"assets":"http:\/\/thedoctorsonline.org\/wp-content\/plugins\/elementor\/assets\/"},"ajax":{"url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin-ajax.php","nonce":"db5e0b49bd"},"finder":{"data":{"edit":{"title":"Edit","dynamic":true,"name":"edit"},"general":{"title":"General","dynamic":false,"items":{"my-templates":{"title":"My Templates","icon":"library-save","url":"http:\/\/thedoctorsonline.org\/wp-admin\/edit.php?post_type=elementor_library","keywords":["template","header","footer","single","archive","search","404 page","library"]},"system-info":{"title":"System Info","icon":"info","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-system-info","keywords":["system","info","environment","elementor"]},"role-manager":{"title":"Role Manager","icon":"person","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-role-manager","keywords":["role","manager","user","elementor"]},"knowledge-base":{"title":"Knowledge Base","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=go_knowledge_base_site","keywords":["help","knowledge","docs","elementor"]}},"name":"general"},"create":{"title":"Create","dynamic":false,"items":{"post":{"title":"Add New Post","icon":"plus-circle","url":"http:\/\/thedoctorsonline.org\/wp-admin\/edit.php?action=elementor_new_post&post_type=post&_wpnonce=058b42bc20","keywords":["post","page","template","new","create"]},"page":{"title":"Add New Page","icon":"plus-circle","url":"http:\/\/thedoctorsonline.org\/wp-admin\/edit.php?action=elementor_new_post&post_type=page&_wpnonce=058b42bc20","keywords":["post","page","template","new","create"]},"elementor_library":{"title":"Add New Template","icon":"plus-circle","url":"http:\/\/thedoctorsonline.org\/wp-admin\/edit.php?post_type=elementor_library#add_new","keywords":["post","page","template","new","create"]}},"name":"create"},"site":{"title":"Site","dynamic":false,"items":{"homepage":{"title":"Homepage","url":"http:\/\/thedoctorsonline.org","icon":"home-heart","keywords":["home","page"]},"wordpress-dashboard":{"title":"Dashboard","icon":"dashboard","url":"http:\/\/thedoctorsonline.org\/wp-admin\/","keywords":["dashboard","wordpress"]},"wordpress-menus":{"title":"Menus","icon":"wordpress","url":"http:\/\/thedoctorsonline.org\/wp-admin\/nav-menus.php","keywords":["menu","wordpress"]},"wordpress-customizer":{"title":"Customizer","icon":"wordpress","url":"http:\/\/thedoctorsonline.org\/wp-admin\/customize.php","keywords":["customizer","wordpress"]},"wordpress-plugins":{"title":"Plugins","icon":"wordpress","url":"http:\/\/thedoctorsonline.org\/wp-admin\/plugins.php","keywords":["plugins","wordpress"]},"wordpress-users":{"title":"Users","icon":"wordpress","url":"http:\/\/thedoctorsonline.org\/wp-admin\/users.php","keywords":["users","profile","wordpress"]}},"name":"site"},"settings":{"title":"Settings","dynamic":false,"items":{"general-settings":{"title":"General Settings","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor","keywords":["general","settings","elementor"]},"style":{"title":"Style","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor#tab-style","keywords":["style","settings","elementor"]},"advanced":{"title":"Advanced","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor#tab-advanced","keywords":["advanced","settings","elementor"]}},"name":"settings"},"tools":{"title":"Tools","dynamic":false,"items":{"tools":{"title":"Tools","icon":"tools","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-tools","keywords":["tools","elementor"]},"replace-url":{"title":"Replace URL","icon":"tools","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-tools#tab-replace_url","keywords":["tools","replace url","domain","elementor"]},"version-control":{"title":"Version Control","icon":"time-line","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-tools#tab-versions","keywords":["tools","version","control","beta","elementor"]},"maintenance-mode":{"title":"Maintenance Mode","icon":"tools","url":"http:\/\/thedoctorsonline.org\/wp-admin\/admin.php?page=elementor-tools#tab-maintenance_mode","keywords":["tools","maintenance","coming soon","elementor"]}},"name":"tools"}},"i18n":{"finder":"Finder"}},"connect":[]};
/* ]]> */
</script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-content/plugins/elementor/assets/js/common.min.js?ver=2.3.8'></script>
<script type='text/javascript' src='http://thedoctorsonline.org/wp-includes/js/wp-embed.min.js?ver=5.0.3'></script>
    <!--[if lte IE 8]>
        <script type="text/javascript">
            document.body.className = document.body.className.replace( /(^|\s)(no-)?customize-support(?=\s|$)/, '' ) + ' no-customize-support';
        </script>
    <![endif]-->
    <!--[if gte IE 9]><!-->
        <script type="text/javascript">
            (function() {
                var request, b = document.body, c = 'className', cs = 'customize-support', rcs = new RegExp('(^|\\s+)(no-)?'+cs+'(\\s+|$)');

                        request = true;
        
                b[c] = b[c].replace( rcs, ' ' );
                // The customizer requires postMessage and CORS (if the site is cross domain)
                b[c] += ( window.postMessage && request ? ' ' : ' no-' ) + cs;
            }());
        </script>
    <!--<![endif]-->
            <div id="wpadminbar" class="nojq nojs">
                            <a class="screen-reader-shortcut" href="#wp-toolbar" tabindex="1">Skip to toolbar</a>
                        <div class="quicklinks" id="wp-toolbar" role="navigation" aria-label="Toolbar" tabindex="0">
                <ul id="wp-admin-bar-root-default" class="ab-top-menu">
        <li id="wp-admin-bar-wp-logo" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://thedoctorsonline.org/wp-admin/about.php"><span class="ab-icon"></span><span class="screen-reader-text">About WordPress</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-wp-logo-default" class="ab-submenu">
        <li id="wp-admin-bar-about"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/about.php">About WordPress</a>        </li></ul><ul id="wp-admin-bar-wp-logo-external" class="ab-sub-secondary ab-submenu">
        <li id="wp-admin-bar-wporg"><a class="ab-item" href="https://wordpress.org/">WordPress.org</a>      </li>
        <li id="wp-admin-bar-documentation"><a class="ab-item" href="https://codex.wordpress.org/">Documentation</a>        </li>
        <li id="wp-admin-bar-support-forums"><a class="ab-item" href="https://wordpress.org/support/">Support Forums</a>        </li>
        <li id="wp-admin-bar-feedback"><a class="ab-item" href="https://wordpress.org/support/forum/requests-and-feedback">Feedback</a>     </li></ul></div>        </li>
        <li id="wp-admin-bar-site-name" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://thedoctorsonline.org/wp-admin/">TheDoctorsOnline</a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-site-name-default" class="ab-submenu">
        <li id="wp-admin-bar-dashboard"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/">Dashboard</a>       </li></ul><ul id="wp-admin-bar-appearance" class="ab-submenu">
        <li id="wp-admin-bar-themes"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/themes.php">Themes</a>       </li>
        <li id="wp-admin-bar-widgets"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/widgets.php">Widgets</a>        </li>
        <li id="wp-admin-bar-menus"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/nav-menus.php">Menus</a>      </li></ul></div>        </li>
        <li id="wp-admin-bar-customize" class="hide-if-no-customize"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/customize.php?url=http%3A%2F%2Fthedoctorsonline.org%2Fcheck-your-medical-symptoms%2F">Customize</a>      </li>
        <li id="wp-admin-bar-updates"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/update-core.php" title="1 Plugin Update"><span class="ab-icon"></span><span class="ab-label">1</span><span class="screen-reader-text">1 Plugin Update</span></a>        </li>
        <li id="wp-admin-bar-comments"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/edit-comments.php"><span class="ab-icon"></span><span class="ab-label awaiting-mod pending-count count-0" aria-hidden="true">0</span><span class="screen-reader-text">0 comments awaiting moderation</span></a>        </li>
        <li id="wp-admin-bar-new-content" class="menupop"><a class="ab-item" aria-haspopup="true" href="http://thedoctorsonline.org/wp-admin/post-new.php"><span class="ab-icon"></span><span class="ab-label">New</span></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-new-content-default" class="ab-submenu">
        <li id="wp-admin-bar-new-post"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/post-new.php">Post</a>     </li>
        <li id="wp-admin-bar-new-media"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/media-new.php">Media</a>      </li>
        <li id="wp-admin-bar-new-page"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/post-new.php?post_type=page">Page</a>      </li>
        <li id="wp-admin-bar-new-give_forms"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/post-new.php?post_type=give_forms">Donation Form</a>     </li>
        <li id="wp-admin-bar-new-user"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/user-new.php">User</a>     </li>
        <li id="wp-admin-bar-new-content-happyforms"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/customize.php?return=http%3A%2F%2Fthedoctorsonline.org%2Fwp-admin%2Fedit.php%3Fpost_type%3Dhappyform&#038;happyforms=1&#038;form_id=0#build" target="_self" title="New HappyForm">HappyForm</a>      </li></ul></div>        </li>
        <li id="wp-admin-bar-edit"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/post.php?post=1598&#038;action=edit">Edit Page</a>     </li>
        <li id="wp-admin-bar-epc_purge_menu" class="menupop"><div class="ab-item ab-empty-item" aria-haspopup="true">Caching</div><div class="ab-sub-wrapper"><ul id="wp-admin-bar-epc_purge_menu-default" class="ab-submenu">
        <li id="wp-admin-bar-epc_purge_menu-purge_all"><a class="ab-item" href="/check-your-medical-symptoms/?epc_purge_all=1">Purge All</a>        </li>
        <li id="wp-admin-bar-epc_purge_menu-purge_single"><a class="ab-item" href="/check-your-medical-symptoms/?epc_purge_single=1">Purge This Page</a>        </li>
        <li id="wp-admin-bar-epc_purge_menu-cache_settings"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/options-general.php#epc_settings">Cache Settings</a>      </li></ul></div>        </li></ul><ul id="wp-admin-bar-top-secondary" class="ab-top-secondary ab-top-menu">
        <li id="wp-admin-bar-search" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1"><form action="http://thedoctorsonline.org/" method="get" id="adminbarsearch"><input class="adminbar-input" name="s" id="adminbar-search" type="text" value="" maxlength="150" /><label for="adminbar-search" class="screen-reader-text">Search</label><input type="submit" class="adminbar-button" value="Search"/></form></div>     </li>
        <li id="wp-admin-bar-my-account" class="menupop with-avatar"><a class="ab-item" aria-haspopup="true" href="http://thedoctorsonline.org/wp-admin/profile.php">Howdy, <span class="display-name">Tolu</span><img alt='' src='http://1.gravatar.com/avatar/7ef857941ff017ed459403e934fdad1f?s=26&#038;d=mm&#038;r=g' srcset='http://1.gravatar.com/avatar/7ef857941ff017ed459403e934fdad1f?s=52&#038;d=mm&#038;r=g 2x' class='avatar avatar-26 photo' height='26' width='26' /></a><div class="ab-sub-wrapper"><ul id="wp-admin-bar-user-actions" class="ab-submenu">
        <li id="wp-admin-bar-user-info"><a class="ab-item" tabindex="-1" href="http://thedoctorsonline.org/wp-admin/profile.php"><img alt='' src='http://1.gravatar.com/avatar/7ef857941ff017ed459403e934fdad1f?s=64&#038;d=mm&#038;r=g' srcset='http://1.gravatar.com/avatar/7ef857941ff017ed459403e934fdad1f?s=128&#038;d=mm&#038;r=g 2x' class='avatar avatar-64 photo' height='64' width='64' /><span class='display-name'>Tolu</span><span class='username'>Symptoms</span></a>        </li>
        <li id="wp-admin-bar-edit-profile"><a class="ab-item" href="http://thedoctorsonline.org/wp-admin/profile.php">Edit My Profile</a>       </li>
        <li id="wp-admin-bar-logout"><a class="ab-item" href="http://thedoctorsonline.org/wp-login.php?action=logout&#038;_wpnonce=54f9ce9f5b">Log Out</a>      </li></ul></div>        </li></ul>          </div>
                        <a class="screen-reader-shortcut" href="http://thedoctorsonline.org/wp-login.php?action=logout&#038;_wpnonce=54f9ce9f5b">Log Out</a>
                    </div>

        
    </body>
</html>